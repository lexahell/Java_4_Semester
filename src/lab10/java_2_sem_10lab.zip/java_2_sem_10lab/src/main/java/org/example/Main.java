package org.example;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

interface Lighter {
    void doLight();
}

class Lamp implements Lighter {
    @Override
    public void doLight() {
        System.out.println("Lamp lights up the room.");
    }
}

class Flashlight implements Lighter {
    @Override
    public void doLight() {
        System.out.println("Flashlight shines brightly.");
    }
}

class Firefly implements Lighter {
    @Override
    public void doLight() {
        System.out.println("Firefly glows softly in the dark.");
    }
}

@Configuration
class AppConfig {
    @Bean(name = "lamp")
    public Lighter lamp() {
        return new Lamp();
    }

    @Bean(name = "flashlight")
    public Lighter flashlight() {
        return new Flashlight();
    }

    @Bean(name = "firefly")
    public Lighter firefly() {
        return new Firefly();
    }
}
@SpringBootApplication
public class Main {
    public static void main(String[] args) {
//        System.out.println("Asdasfsdgsdgs");
        if (args.length != 1) {
            System.out.println("Usage: java Application <beanName>");
            return;
        }

        String beanName = args[0];

        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        Lighter lighter = context.getBean(args[0], Lighter.class);
        lighter.doLight();

    }
}
